const firebaseConfig = {
  apiKey: "AIzaSyAsLORPPGH5Tk3DFLMnYISSDjK-GXwauvs",
  authDomain: "shradha-40af6.firebaseapp.com",
  projectId: "shradha-40af6",
  storageBucket: "shradha-40af6.appspot.com",
  messagingSenderId: "835751194112",
  appId: "1:835751194112:web:b03e6b31defcc54fc732e5",
  measurementId: "G-3C0SBNG7QN"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
