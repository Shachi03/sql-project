Simple website created using HTML, CSS &amp; Javascript with smooth scroll effect

Watch the full tutorial on how I built this website on my Youtube @Brian Design https://youtu.be/3-2Pj5hxwrw

